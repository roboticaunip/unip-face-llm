Arquitetura modular ASR → LLM → TTS → Visual
