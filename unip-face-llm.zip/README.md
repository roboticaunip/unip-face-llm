# 🤖 UNIP Face LLM

Assistente de voz com rosto animado usando Vosk, Gemini e Piper TTS.

## Execução
```bash
python src/unip_face/main.py
```
